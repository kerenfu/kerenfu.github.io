function varargout = ihashfind(varargin)
% VL_IHASHFIND
%  SEL = VL_IHASHFIND(ID, NEXT, K, X)
[varargout{1:nargout}] = vl_ihashfind(varargin{:});
