function segments=slic_segmentation(Im,K,regularizer)

[oh,ow,os]=size(Im);

regionSize = ceil(sqrt(oh*ow/K));

segments = 1+vl_slic(Im, regionSize, regularizer) ;%Lab��ʹ��SLIC

vl_fuck=unique(segments(:));

vl_fuck_length=length(vl_fuck);

if max(segments(:))~=vl_fuck_length%���vlfeat�ָ��������
   for i=1:1:vl_fuck_length
       segments(find(segments==vl_fuck(i)))=i;
   end
end

% labelnumber=max(segments(:));
% 
% addition_labelnumber=labelnumber+1;
% 
% for i=1:1:labelnumber
%     A=zeros(oh,ow);
%     A(find(segments==i))=1;
%     L = bwlabeln(A);
%     temp=max(L(:));
%     if temp>1%��Ϊ�����ͨ����
%        for j=2:1:temp
%            segments(find(L==j))=addition_labelnumber;
%            addition_labelnumber=addition_labelnumber+1;
%        end
%     end
% end

end