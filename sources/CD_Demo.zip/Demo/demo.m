clc;
close all;
clear all;

abc_path = [ 'test_img\'];     
abc_filelist = dir([abc_path '/*.jpg']);   
addpath(genpath('./vl_toolbox'));
len = length(abc_filelist);
for Pix=1:len 
Pix
string_file=abc_filelist(Pix).name
Or= double(imread([abc_path string_file]))/255;%RGB image
[h,w,s]=size(Or);%size
Orlab = vl_xyz2lab(vl_rgb2xyz(Or)) ;%LAB image
Im=im2single(Orlab);
Distr=double(imread('prior\pmap.png'))/255;%distribution prior
Distr=imresize(Distr,[h,w]);%resize distribution prior
Combined_Saliency_Map=zeros(h,w);
Refinement_Saliency_Map=zeros(h,w);

%%
%%------------------------SLIC superpixels---------------------%%

K=500;

regularizer = 100;%100

t1=clock;
segments=slic_segmentation(Im,K,regularizer);
t2=clock;
labelnumber=max(segments(:));

seg_mean=zeros(labelnumber,3);%mean color in LAB
seg_location_mean=zeros(labelnumber,2);%mean position
dis_mean=zeros(labelnumber,3);%mean color in RGB

Orlab_c=reshape(Orlab,[h*w,3]);
Or_c=reshape(Or,[h*w,3]);
[ww,hh]=meshgrid(1:w,1:h);
P_c=reshape(cat(3,hh,ww),[h*w,2]);
for i=1:1:labelnumber
    index=find(segments==i);
    seg_mean(i,:)=sum(Orlab_c(index,:),1)/length(index);
    dis_mean(i,:)=sum(Or_c(index,:),1)/length(index);
    seg_location_mean(i,:)=sum(P_c(index,:),1)/length(index);
end
%%
%%------------------------Color vector normalization---------------------%%
color_mean_normalized=wightening([seg_mean,dis_mean],1);%6D color vector
tmp1=repmat(permute(color_mean_normalized,[1 3 2]),[1 labelnumber 1]);
tmp2=repmat(permute(color_mean_normalized',[3 2 1]),[labelnumber 1 1]);
color_mean_differentiation=sum((tmp1-tmp2).^2,3);%normalized 6D distance square

tmp1=repmat(permute(seg_mean,[1 3 2]),[1 labelnumber 1]);
tmp2=repmat(permute(seg_mean',[3 2 1]),[labelnumber 1 1]);
seg_mean_D=sum((tmp1-tmp2).^2,3).^0.5;%unormalized LAB distance

%%
%%------------------------Color contrast---------------------%%
alpha=5e-5;%spatial para
Prior=[];
for i=1:1:labelnumber
    Prior=[Prior;Distr(round(seg_location_mean(i,1)),round(seg_location_mean(i,2)))];
end
t3=clock;
Saliency=sum(color_mean_differentiation,2).*(Prior);

%%
%%------------------------Saliency smoothing---------------------%%
KN=round(labelnumber/1);
[sort_mean_DS,I]=sort(seg_mean_D,2);
KNN_seg_mean_DS=ones(labelnumber)*Inf;

for v=1:1:labelnumber
    KNN_seg_mean_DS(v,I(v,1:KN))=sort_mean_DS(v,1:KN);%first KN distance remain
end 

gamma=1e-3;%0.001for exp 
% W=exp(-gamma*seg_mean_D);
W=exp(-(gamma*KNN_seg_mean_DS).^1);
W=W./repmat(sum(W,2),[1,labelnumber]);%smoothing weight matrix
Saliency=W*Saliency;
%%------------------------Color distribution---------------------%%
beta=0.1;%0.1for exp
W=exp(-beta*seg_mean_D);
W=W./repmat(sum(W,2),[1,labelnumber]);%similarity matrix
Distribution=sum(W*(seg_location_mean.^2)-(W*seg_location_mean).^2,2);
t4=clock;
%%
%%------------------------Combination---------------------%%
Distribution=(Distribution-min(Distribution))/(max(Distribution)-min(Distribution));
Saliency=(Saliency-min(Saliency))/(max(Saliency)-min(Saliency));
Combined_Saliency=(1-Distribution).*Saliency;
% Combined_Saliency=Saliency;
Combined_Saliency=(Combined_Saliency-min(Combined_Saliency))/(max(Combined_Saliency)-min(Combined_Saliency));

% inverse=(1-Distribution);

for i=1:1:labelnumber
    index=find(segments==i);
    Combined_Saliency_Map(index)=Combined_Saliency(i);
end
%%
%%------------------------Refinement---------------------%%
t5=clock;
[~,segments2] = edison_wrapper(Or,@RGB2Luv,'RangeBandWidth',6.5,'MinimumRegionArea',240);
t6=clock;
segments2 = 1+segments2;
labelnumber2=max(segments2(:));

for i=1:1:labelnumber2
    index=find(segments2==i);
    Refinement_Saliency_Map(index)=mean(Combined_Saliency_Map(index));
end

Refinement_Saliency_Map=(Refinement_Saliency_Map-min(Refinement_Saliency_Map(:)))/(max(Refinement_Saliency_Map(:))-min(Refinement_Saliency_Map(:)));

%%
%%------------------------Save result---------------------%%
imwrite(Refinement_Saliency_Map,strcat(string_file(1:end-4),'_CD.png'));
pre_time=etime(t2,t1);
our_time=etime(t4,t3);
pos_time=etime(t6,t5);
disp([num2str(pre_time) ',' num2str(our_time) ',' num2str(pos_time) ',' 'total=' num2str(pre_time+our_time+pos_time)] );
end


