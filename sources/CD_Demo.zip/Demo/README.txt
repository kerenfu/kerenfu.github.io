The code (V1) is for: 
===========================================================================
K. Fu, C. Gong, J. Yang, and Y. Zhou, I. Gu 
Superpixel based color contrast and color distribution driven salient object detection 
Signal Processing: Image Communication, 28(10):1448-1463, 2013       
===========================================================================
The code has been tested on Window with 32bit/62bit matlab.
===========================================================================
How to run a simple demo:
===========================================================================
0a. put test images (*.jpg format) into 'test_img' folder; 
1a. run 'demo.m' to see the results; 
