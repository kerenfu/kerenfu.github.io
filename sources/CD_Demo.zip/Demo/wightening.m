function result=wightening(matrix,dim)
[r,c]=size(matrix);
if dim==1
    mean_matrix=repmat(mean(matrix,1),[r,1]);
    std_matrix=repmat(std(matrix,0,1),[r,1]);
    result=(matrix-mean_matrix)./std_matrix;
elseif dim==2
    mean_matrix=repmat(mean(matrix,2),[1,c]);
    std_matrix=repmat(std(matrix,0,2),[1,c]);
    result=(matrix-mean_matrix)./std_matrix;
else
    error('dim should be 1 or 2!');
end
