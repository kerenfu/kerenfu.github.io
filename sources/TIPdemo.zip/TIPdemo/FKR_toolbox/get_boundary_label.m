function boundary_label=get_boundary_label(segments,labelnumber)
boundary_label=zeros(labelnumber,4);
[h,w,s]=size(segments);

boundary_label(segments(1,1:w),1)=1;%up

boundary_label(segments(h,1:w),2)=1;%down

boundary_label(segments(1:h,1),3)=1;%left

boundary_label(segments(1:h,w),4)=1;%right

end