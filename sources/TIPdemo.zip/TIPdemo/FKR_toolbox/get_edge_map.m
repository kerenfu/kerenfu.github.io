function edge_map=get_edge_map(segments,edge_matrix)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[oh,ow,~]=size(segments);
edge_map=zeros([oh,ow]);
for i=1:1:oh-1
    for j=1:1:ow-1
          if segments(i,j)~=segments(i+1,j)
              edge_map(i,j)=edge_matrix(segments(i,j),segments(i+1,j));
          end
        
          if segments(i,j)~=segments(i,j+1)
              edge_map(i,j)=edge_matrix(segments(i,j),segments(i,j+1));
          end
        
          if segments(i,j)~=segments(i+1,j+1)%required if 8 neighbourhood
              edge_map(i,j)=edge_matrix(segments(i,j),segments(i+1,j+1));
          end
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

edge_map=normalization(edge_map);

end