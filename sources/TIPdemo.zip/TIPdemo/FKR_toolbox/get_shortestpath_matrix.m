function seg_shortestpath_matrix=get_shortestpath_matrix(seg_edge_matrix,labelnumber)
%output matrix: ijth element record the shortest distance (geodesic) from ith segment to the jth segment 
seg_shortestpath_matrix=zeros(labelnumber);

%%%%%%%%%using dijkstra of the mex need the following code%%%%%%%%%%%%%%%%%
seg_edge_matrix=seg_edge_matrix+0.00001;%use small number to represent 0
seg_edge_matrix(find(seg_edge_matrix==Inf))=100000;%use large number to represent Inf
seg_edge_matrix=sparse(seg_edge_matrix);

seg_shortestpath_matrix=dijkstra(seg_edge_matrix,double(1:labelnumber));


% for i=1:1:labelnumber
%     index=find(seg_edge_matrix(i,:)==0&1:labelnumber<i);
%     if isempty(index)==1
%         D=dijkstra(seg_edge_matrix,i);%find geodesic distance using dijkstra
%         D=D';%convert into row vector
%         seg_shortestpath_matrix(i,:)=D;
%     else
%        seg_shortestpath_matrix(i,:)=seg_shortestpath_matrix(min(index),:);
%     end
% 
% end

end