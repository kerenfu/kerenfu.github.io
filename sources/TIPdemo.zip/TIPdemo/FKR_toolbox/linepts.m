function result = linepts(a, b)
%get coordinates on a line from point a to point b

yy1=a(1);
xx1=a(2);
yy2=b(1);
xx2=b(2);
angletox=atan2((yy2-yy1),(xx2-xx1));
TERMINATE=round(norm(a-b));
result=[];
y=yy1;
x=xx1;
for R=0:1:TERMINATE
    sample_y=round(R*sin(angletox)+y);
    sample_x=round(R*cos(angletox)+x);
    result=[result;sample_y,sample_x];
end
 