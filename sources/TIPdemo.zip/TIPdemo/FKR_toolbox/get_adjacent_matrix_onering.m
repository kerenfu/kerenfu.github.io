function seg_adjacent_matrix=get_adjacent_matrix_onering(segments)

[h,w,~]=size(segments);
unique_index=unique(segments);
labelnumber=length(unique_index);
seg_adjacent_matrix=ones(labelnumber)*Inf;
%%compute adjacent matrix at 8 neighbourhood
for i=1:1:h-1
    for j=1:1:w-1
          if segments(i,j)~=segments(i+1,j)
              seg_adjacent_matrix(unique_index==segments(i,j),unique_index==segments(i+1,j))=1;
              seg_adjacent_matrix(unique_index==segments(i+1,j),unique_index==segments(i,j))=1;
          end
        
          if segments(i,j)~=segments(i,j+1)
              seg_adjacent_matrix(unique_index==segments(i,j),unique_index==segments(i,j+1))=1;
              seg_adjacent_matrix(unique_index==segments(i,j+1),unique_index==segments(i,j))=1;
          end
        
          if segments(i,j)~=segments(i+1,j+1)%required if 8 neighbourhood
              seg_adjacent_matrix(unique_index==segments(i,j),unique_index==segments(i+1,j+1))=1;
              seg_adjacent_matrix(unique_index==segments(i+1,j+1),unique_index==segments(i,j))=1;
          end
          
    end
end


% % % connect boundary superpixel
bd=unique([segments(1,:),segments(h,:),segments(:,1)',segments(:,w)']);
for i=1:length(bd)
    for j=i+1:length(bd)
        seg_adjacent_matrix(unique_index==bd(i),unique_index==bd(j))=1;
        seg_adjacent_matrix(unique_index==bd(j),unique_index==bd(i))=1;
    end
end

seg_adjacent_matrix=seg_adjacent_matrix+diag(ones(labelnumber,1)*Inf);

end