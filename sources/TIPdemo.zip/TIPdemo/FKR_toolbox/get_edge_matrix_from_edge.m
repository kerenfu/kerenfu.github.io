function [seg_edge_matrix,max_diff]=get_edge_matrix_from_edge(seg_adjacent_matrix,seg_location,edge_map,boundary_label,seg_color_edge_matrix,labelnumber)
%get difference from edge detection

seg_edge_matrix=ones(labelnumber)*Inf;
max_diff=0;
for i=1:1:labelnumber
    for j=i+1:1:labelnumber
        if seg_adjacent_matrix(i,j)==1
            if boundary_label(i)==1&&boundary_label(j)==1
                current_edge=seg_color_edge_matrix(i,j);
            else
                pts=linepts(seg_location(i,:),seg_location(j,:));
                index=sub2ind(size(edge_map),pts(:,1),pts(:,2));
                current_edge=max(edge_map(index));
            end
            seg_edge_matrix(i,j)=current_edge;
            seg_edge_matrix(j,i)=current_edge;
            if current_edge>max_diff
                max_diff=current_edge;
            end
        end
    end
end




