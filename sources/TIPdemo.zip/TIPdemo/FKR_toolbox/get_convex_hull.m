function [final_x,final_y]=get_convex_hull(input_img)
%output=x,y is the boundary points of the hull
[h,w,s]=size(input_img);
Corner_list = Color_Boosted_Harris_Detector(input_img);
x=Corner_list(:,1);
y=Corner_list(:,2);
len_x=length(x);
board_roatio=0.1;
i=1;
while i<=len_x%eliminate the corners that near the image boundary
    if x(i)<board_roatio*w||x(i)>(1-board_roatio)*w||y(i)>(1-board_roatio)*h||y(i)<board_roatio*h
       x(i)=[];
       y(i)=[];
       i=i-1; 
       len_x=len_x-1;
    end
    i=i+1;
end


dt = DelaunayTri(x,y);
k = convexHull(dt);
final_x=x(k);final_y=y(k); %x,y only contains the boundary corner points of the convex hull

end