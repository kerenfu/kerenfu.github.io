% Demo for paper "Normalized Cut-Based Saliency Detection by Adaptive Multi-Level Region Merging" 
% by Keren Fu, Chen Gong, Irene Yu-Hua Gu, Jie Yang
% Appeared in IEEE TRANSACTIONS ON IMAGE PROCESSING, VOL. 24, NO. 12, DECEMBER 2015
% Please read "readme.txt" before using this code.
clc;
close all;
clear all;

addpath('./FKR_toolbox/');%unified code
addpath('./FKR_private/');%special code
addpath(genpath('./RF_edge_toolbox'));%edge detection toolbox
addpath(genpath('./piotr_toolbox'));%edge detection toolbox

input_path = [ 'Test_Img\'];    %input image path
output_path= ['SaliencyMap\'];  %output image path
superpixel_path = './Superpixels/'; %temp path for superpixels
% delete([output_path '*.png']);

input_filelist = dir([input_path '/*.jpg']); %get input image list           
len = length(input_filelist);

%%%%%parameters
EnableGlobal=1;     %enable globalization/Ncut   0/1
WeightOfEdge=0.3;	%weight for edge detection  [0.3,0.5]
AreaLimitLow=4;     %lower bound for region area (number of superpxiels, default 4) [0,200]
EnableSmoothing=1;  %enable post-smoothing 0/1
SuperpixelNum=200;  %number of superpixels : default 200
QuanNum=30;         %quantifying number : default 30

time_all_sum=0; 

for Pix=1:len 
disp('-------------------------------------'); 
disp(['Processing ' num2str(Pix) 'th image']); 

%% read image and data preparation
string_file=input_filelist(Pix).name;
Or=imread([input_path string_file]);
if size(Or,3)==1 Or=repmat(Or,[1,1,3]); end
[Or,w]=removeframe(Or);                     %remove image frame
[oh,ow,os]=size(Or);                        %get new size
Or= double((Or))/255;                       %change to double
Orlab = vl_xyz2lab(vl_rgb2xyz(Or)) ;        %rgb to xyz to lab
Distr=double(imread('distribution\result_total.png'))/255;%distribution prior
Distr=imresize(Distr,[oh,ow]);%resize distribution prior

t1=clock;  
%% SLIC superpixels (including edge detection and Ncut)
disp('Superpixel segmentation...');  
segments=get_superpixel(Or,SuperpixelNum,superpixel_path,string_file);
labelnumber=max(segments(:)); 
segments_prop=superpixel_prop(Or,Orlab,Distr,segments,EnableGlobal,WeightOfEdge);
%% Prepare boundary superpixels for contrast
boundary_label=get_boundary_label(segments,labelnumber);
boundary_all=boundary_label(:,1)|boundary_label(:,2)|boundary_label(:,3)|boundary_label(:,4);
boundary_color=segments_prop.seg_mean(boundary_all,:);
boundary_pixel_length=length(boundary_color(:,1));

%% Adaptive region merging
sum_tsaliency_map=zeros(oh,ow); %saliency map
threshold_step=1/QuanNum;            %1/quantifying number
merging_label=(1:segments_prop.num)';
current_threshold=threshold_step;
round=0;
current_segments=segments;
 
while length(unique(merging_label))>1%until the whole image becomes one region
    edge_index_merge=find(segments_prop.seg_edge_vector(:,3)<=current_threshold);
%     round=round+1
    if isempty(edge_index_merge)~=1
        for itr=1:1:length(edge_index_merge)
            sl=segments_prop.seg_edge_vector(edge_index_merge(itr),1);
            ll=segments_prop.seg_edge_vector(edge_index_merge(itr),2);
            merging_label(merging_label==ll)=sl;%merge large label to small label
            
            temp=segments_prop.seg_edge_vector(:,1);%modifying corresponding number
            temp(temp==ll)=sl;
            segments_prop.seg_edge_vector(:,1)=temp;
            
            temp=segments_prop.seg_edge_vector(:,2);%modifying corresponding number
            temp(temp==ll)=sl;
            segments_prop.seg_edge_vector(:,2)=temp;
            
            segments_prop.seg_edge_vector(:,1:2)=sort(segments_prop.seg_edge_vector(:,1:2),2);
        end   
       %%
        segments_prop.seg_edge_vector=segments_prop.seg_edge_vector(segments_prop.seg_edge_vector(:,1)~=segments_prop.seg_edge_vector(:,2),:);

        [~,I,~]=unique(segments_prop.seg_edge_vector(:,1:2),'rows');%unique row
            
        for kk=1:1:length(I)%search for duplicated row and update the weight
            cuurent_row=segments_prop.seg_edge_vector(I(kk),1:2);
            temp_index=find((segments_prop.seg_edge_vector(:,1)==cuurent_row(1))&(segments_prop.seg_edge_vector(:,2)==cuurent_row(2)));
            segments_prop.seg_edge_vector(temp_index,3)=sum(segments_prop.seg_edge_vector(temp_index,3).*(segments_prop.seg_edge_vector(temp_index,4)))/sum(segments_prop.seg_edge_vector(temp_index,4));%update the weight as average
            segments_prop.seg_edge_vector(temp_index,4)=sum(segments_prop.seg_edge_vector(temp_index,4));%update the edge number
        end

        segments_prop.seg_edge_vector=segments_prop.seg_edge_vector(I,:);
        [~,index]=sort(segments_prop.seg_edge_vector(:,3),1,'ascend');
        segments_prop.seg_edge_vector=segments_prop.seg_edge_vector(index,:);
       %%
        current_segments=segments;
        for i=1:1:segments_prop.num
            current_segments(segments==i)=merging_label(i);
        end
        current_region=unique(merging_label);
        
        
       %% compute temp saliency map
        %%%boundary cropping
        boundary_label=get_boundary_label(current_segments,labelnumber); 
        boundary_energy=double(sum(boundary_label,2)<=1);
        boundary_energy=boundary_energy(current_region);
        %%%center prior
        center_prior=get_center_prior(current_segments,Distr,current_region);
        %%%figure-ground contrast
        current_seg_saliency=zeros(length(current_region),1);%mean color in LAB
        for c_itr=1:1:length(current_region)
            current_seg_saliency(c_itr)=...
                distance_measure(segments_prop.seg_mean(merging_label==current_region(c_itr),:),boundary_color);
        end 
        %%%combination
        saliency_vector=current_seg_saliency.*boundary_energy.*center_prior;
        %%%size control
        region_area=get_region_area(merging_label);
        if AreaLimitLow>2
            current_seg_adjacent_matrix=get_adjacent_matrix_onering(current_segments);
            for i=1:1:length(current_region)%refine the size
                if region_area(i)<AreaLimitLow
                    temp_index=find((current_seg_adjacent_matrix(:,i)==1)&(region_area>=AreaLimitLow));%adjacent to that region
                    if isempty(temp_index)==0
                        neighbor_number=length(temp_index);
                        [~,min_index]=min(abs(saliency_vector(i)*ones(neighbor_number,1)-saliency_vector(temp_index)));
                        saliency_vector(i)=saliency_vector(min_index);
                    end
                end
            end
        end
        
        tsaliency_map=zeros(oh,ow);%clear temp saliency map
        for i=1:1:length(current_region)
            tsaliency_map(current_segments==current_region(i))=saliency_vector(i);%
        end
    end
        
    current_threshold=current_threshold+threshold_step;
    tsaliency_map=normalization(tsaliency_map);
    sum_tsaliency_map=(sum_tsaliency_map+tsaliency_map);
end

sum_tsaliency_map=normalization(sum_tsaliency_map);

%% optimal smoothing
if EnableSmoothing==1&&EnableGlobal==1
    saliency_vector=zeros(labelnumber,1);
    for i=1:1:labelnumber
        index=find(segments==i);
        saliency_vector(i)=sum(sum_tsaliency_map(index))/length(index);
    end

    W=segments_prop.W;
    alpha=0.99;
    D  = diag(sum(W));
    optAff =(D-alpha*W)\eye(labelnumber);
    mz=diag(ones(labelnumber,1));
    mz=~mz;
    optAff=optAff.*mz;

    final_filtered=normalization(optAff*saliency_vector);
    
    for i=1:1:labelnumber
        sum_tsaliency_map(segments==i)=final_filtered(i);
    end  
end
%%
t2=clock;
time_all=etime(t2,t1);
time_all_sum=time_all_sum+time_all;
disp(strcat('Time��',num2str(time_all)));  
saliency_map=zeros(w(1),w(2));
saliency_map(w(3):w(4),w(5):w(6))=sum_tsaliency_map;
imwrite(saliency_map,[output_path,string_file(1:end-4),'_NCS.png']);
   
end
disp('average time:')
disp(num2str([time_all_sum/Pix]));