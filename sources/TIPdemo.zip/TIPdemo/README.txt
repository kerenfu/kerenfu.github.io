The code (V1) is for: 
===========================================================================
 Keren Fu, Chen Gong, Irene Yu-Hua Gu, Jie Yang
Normalized Cut-Based Saliency Detection by Adaptive Multi-Level Region Merging 
IEEE Transactions on Image Processing (TIP), 24(12):5671-5683, 2015       
===========================================================================
The code has been tested on Window with 32bit/62bit matlab.
===========================================================================
How to run a simple demo:
===========================================================================
Put the images into folder "Test_Img" and the output saliency maps will be 
in folder "SaliencyMap" by running "Ncut_Saliency_Demo.m".  