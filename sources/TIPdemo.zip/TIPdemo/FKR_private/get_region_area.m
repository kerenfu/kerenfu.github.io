function [region_area]=get_region_area(merging_label)

current_region=unique(merging_label);
labelnumber=length(current_region);

%%
region_area=zeros(labelnumber,1);
for i=1:1:labelnumber
   Total_superpixel=sum(merging_label==current_region(i));
   region_area(i)=Total_superpixel;
end