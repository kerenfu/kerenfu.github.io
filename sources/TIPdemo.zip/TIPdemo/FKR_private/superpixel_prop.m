function segments_prop=superpixel_prop(Or,Orlab,Distr,segments,G_ON,edge_weight)

labelnumber=double(max(segments(:)));%total number

[oh,ow,os]=size(Or);%get new size

seg_mean=zeros(labelnumber,3);%mean color in LAB
dis_mean=zeros(labelnumber,3);%mean color in RGB
seg_location_mean=zeros(labelnumber,2);%mean position
seg_area=zeros(labelnumber,1);%region area
seg_dist=zeros(labelnumber,1);%region distribution

Orlab_c=reshape(Orlab,[oh*ow,3]);%convert into column vector
Or_c=reshape(Or,[oh*ow,3]);
[ww,hh]=meshgrid(1:ow,1:oh);
P_c=reshape(cat(3,hh,ww),[oh*ow,2]);

for i=1:1:labelnumber%average in superpixel
    index=find(segments==i);
    seg_mean(i,:)=sum(Orlab_c(index,:),1)/length(index);
    dis_mean(i,:)=sum(Or_c(index,:),1)/length(index);
    seg_location_mean(i,:)=sum(P_c(index,:),1)/length(index);
    seg_area(i)=length(index);
    seg_dist(i)=sum(Distr(index))^1/length(index);
end

seg_adjacent_matrix=get_adjacent_matrix(segments);%superpixel adjacency

%% load pre-trained edge detection model and set opts (see edgesDemo.m)
disp('Performing edge detection...');  
model=load('./RF_edge_toolbox/models/forest/modelBsds'); model=model.model;
model.opts.nms=-1; model.opts.nThreads=4;
model.opts.multiscale=1; model.opts.sharpen=2;
[E,~,~,~]=edgesDetect(Or,model);
E=E/max(E(:));

%% compute superpixel difference
boundary_label=im2bw(get_boundary_label(segments,labelnumber));%boundary label
boundary_label_all=(boundary_label(:,1)|boundary_label(:,2)|boundary_label(:,3)|boundary_label(:,4));%boundary label all

[seg_edge_matrix2,max_edge2]=get_edge_matrix(seg_adjacent_matrix,seg_mean,labelnumber,'difference');%color term

[seg_edge_matrix1,max_edge1]=get_edge_matrix_from_edge(seg_adjacent_matrix,seg_location_mean,double(E),boundary_label_all,seg_edge_matrix2/max_edge2,labelnumber);%edge term

seg_edge_matrix=(edge_weight+eps)*seg_edge_matrix1/max_edge1+(1-edge_weight-eps)*seg_edge_matrix2/max_edge2;

max_edge=max(seg_edge_matrix((seg_edge_matrix(:)~=Inf)));%recompute the maximal edge

    
if G_ON==1% if globalization/Ncut on, reconstruct the graph edge
    disp('Performing Ncut...');  
    alpha=10;
    W=exp(-alpha*seg_edge_matrix/max_edge);%affinity
    [seg_edge_matrix,max_edge]=globalization(W,seg_adjacent_matrix,8);
    seg_edge_matrix=seg_edge_matrix/max_edge;
else
    seg_edge_matrix=seg_edge_matrix/max_edge;
end

%% convert matrix to a vector
index=find(seg_adjacent_matrix(:)==1);%adjacent

if isempty(index)~=1

    [R,C]=ind2sub([labelnumber labelnumber],index);

    RC=[R,C];         

    RC=sort(RC,2);

    RC=unique([RC,seg_edge_matrix(index),ones(length(index),1)],'rows');%remove duplicated one
    
    [~,index]=sort(RC(:,3),1,'ascend');

    seg_edge_vector=RC(index,:);%sort edges in ascending order
else
    seg_edge_vector=[];
end

%%
segments_prop.num=labelnumber;
segments_prop.seg_mean=seg_mean;
segments_prop.dis_mean=dis_mean;
segments_prop.seg_location_mean=seg_location_mean;
segments_prop.seg_area=seg_area;
segments_prop.seg_adjacent_matrix=seg_adjacent_matrix;
segments_prop.seg_edge_matrix=seg_edge_matrix;
segments_prop.seg_edge_vector=seg_edge_vector;
segments_prop.max_edge=max_edge;
segments_prop.E=E;
if G_ON==1
    segments_prop.W=W;
end
