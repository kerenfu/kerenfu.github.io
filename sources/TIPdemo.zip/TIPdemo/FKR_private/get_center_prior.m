function seg_dist=get_center_prior(segments,Distr,current_region)

labelnumber=length(current_region);
seg_dist=zeros(labelnumber,1);
for i=1:1:labelnumber
    index=find(segments==current_region(i));
    seg_dist(i)=sum(Distr(index))^1/length(index);
end