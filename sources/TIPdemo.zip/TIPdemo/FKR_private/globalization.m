function [new_seg_edge_matrix,new_max_edge]=globalization(W,seg_adjacent_matrix,k)

labelnumber=size(seg_adjacent_matrix,1);

D  = diag(sum(W)); 

L=D-W;
%%%%%%%%%%%%%%%%%%%%%%%%Method 1%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[V dummy] = eigs(L, D, labelnumber-1);%generalized eigenvectiors

V=V(:,labelnumber-1:-1:labelnumber-k);%k smallest eigenvectiors

dummy=diag(dummy);%eigenvalues

E=dummy(labelnumber-1:-1:labelnumber-k);%k smallest eigenvalues

%%%%%%%%%%%%%%%%%%%%%%%%%Method 2%%%%%%%%%%%%%%%%
% [V dummy] = eigs(L, D, k+1, 'SM');%generalized eigenvectiors
% V=V(:,end-1:-1:1);
% dummy=diag(dummy);%eigenvalues
% E=dummy(end-1:-1:1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
EW=1./sqrt(E);%weight from eigenvalues

new_seg_edge_matrix=zeros(labelnumber);

for i=1:1:k
    [seg_edge_matrix,~]=get_edge_matrix(seg_adjacent_matrix,normalization(V(:,i)),labelnumber,'difference');
    new_seg_edge_matrix=new_seg_edge_matrix+seg_edge_matrix*EW(i);%integration
end

new_max_edge=max(new_seg_edge_matrix((new_seg_edge_matrix(:)~=Inf)));



