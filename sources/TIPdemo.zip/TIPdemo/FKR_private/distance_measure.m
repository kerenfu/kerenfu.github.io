function distance=distance_measure(set1,set2)
if size(set1,2)~=size(set2,2)
    error('Sets should have the same dimension');
end
Num1=size(set1,1);Num2=size(set2,1);
temp1=zeros(Num1,1);
for i=1:1:Num1
    temp1(i)=sum(sqrt(sum((repmat(set1(i,:),[Num2,1])-set2).^2,2)));
end
distance=sum(temp1)/(Num1*Num2);