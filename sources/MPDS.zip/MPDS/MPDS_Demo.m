clc;
close all;
clear all;

addpath(genpath('./Code/'));%our code
addpath(genpath('./HarrisCorner/'));% code
addpath(genpath('./gbvs/'));% code
addpath(genpath('./MSALP/'));% code
InputPath = [ 'Img\'];    %input image path
Output= ['SaliencyMap\'];  %output image path
delete([Output,'*.png']);
Superpixel = './Superpixels/'; %temp path for superpixels
InputFileList = dir([InputPath '/*.jpg']); %get input image list   
len = length(InputFileList);
SuperpixelNum=400;  %number of superpixels : 400

for Pix=1:len 
disp('-------------------------------------'); 
disp(['Processing ' num2str(Pix) 'th image']); 
%% read image and data preparation
StringFile=InputFileList(Pix).name;
OrImg=imread([InputPath StringFile]);
if size(OrImg,3)==1 OrImg=repmat(OrImg,[1,1,3]); end
[OrImg,w]=removeframe(OrImg);                     %remove image frame
[oh,ow,os]=size(OrImg);                           %get new size
OrImg= double((OrImg))/255;                       %change to double
OrImglab = vl_xyz2lab(vl_rgb2xyz(OrImg)) ;        %rgb to xyz to lab
 
t1=clock;
%% SLIC superpixels
disp('Superpixel segmentation...');  
segments=get_superpixel(OrImg,SuperpixelNum,Superpixel,StringFile); 
labelnumber=max(segments(:));
segments_prop=superpixel_prop(OrImg,OrImglab,segments); 
%% Prepare affinity matrices 
Num_ring=2;
seg_adjacent_matrix=get_adjacent_matrix(segments,Num_ring);%superpixel adjacency
[SoftAff,segma]=get_color_affinity(segments,seg_adjacent_matrix,[segments_prop.seg_mean],20);
[HardAff,SoftAff_Check,Curve,L]=AffinityOptimization(seg_adjacent_matrix,[segments_prop.seg_mean],segma);
disp((diag(L))');% the learned affinity for L, a, b 
CW=get_color_affinity_LLE(segments,seg_adjacent_matrix,segments_prop.seg_mean,1e-4);
%% boundary label and weight matrix    
BoundaryLabel=get_boundary_label(segments,labelnumber); 
%% convex hull lable
[x,y]=get_convex_hull(OrImg);%%get convex hull 
hull_lable1=inpolygon(round(segments_prop.seg_location_mean(:,2)),round(segments_prop.seg_location_mean(:,1)),x,y);%1 for inside and 0 for outside
  
[x,y]=get_foci_hull(OrImg,10);%%get foci hull
hull_lable2=inpolygon(round(segments_prop.seg_location_mean(:,2)),round(segments_prop.seg_location_mean(:,1)),x,y);%1 for inside and 0 for outside

hull_lable=double(hull_lable1|hull_lable2);
%% A_hard 
W=HardAff;%HardAff or use SoftAff_Check
D  = diag(sum(W));
L=D-W;
K=D; 
mu=0.01; 
lamda=0.1;
I=eye(labelnumber);
A_hard=(L+lamda*(I-CW)'*(I-CW)+mu*K)\K;
A_hard(A_hard<0)=0; 
A_hard=set_zeros_diag(A_hard);
[hardstage1,hardstage1hull,hardstage2,hardbin,mapv1,mapv2,mapv3,mapv4]=SaliencyDiffusion(A_hard,BoundaryLabel,hull_lable);%ranking

t2=clock;
%% output
output_map=zeros(oh,ow);
for i=1:1:labelnumber
        indx=(segments==i);
        output_map(indx)=hardstage2(i);
end  

final_map=zeros(w(1),w(2));

final_map(w(3):w(4),w(5):w(6))=output_map;

imwrite(final_map,[Output,StringFile(1:end-4),'_MPDS.png']);
pre_time=etime(t2,t1);
disp(['total=' num2str(pre_time)]);
end

