function boundary_label=get_boundary_label(segments,labelnumber)
boundary_label=zeros(labelnumber,4);
[h,w,s]=size(segments);

boundary_label(unique(segments(1:5,1:w)),1)=1;%up

boundary_label(unique(segments(h-4:h,1:w)),2)=1;%down

boundary_label(unique(segments(1:h,1:5)),3)=1;%left

boundary_label(unique(segments(1:h,w-4:w)),4)=1;%right

end