function segments_prop=superpixel_prop(Or,Orlab,segments)

labelnumber=double(max(segments(:)));%total number

[oh,ow,os]=size(Or);%get new size

seg_mean=zeros(labelnumber,3);%mean color in LAB
dis_mean=zeros(labelnumber,3);%mean color in RGB
seg_location_mean=zeros(labelnumber,2);%mean position

Orlab_c=reshape(Orlab,[oh*ow,3]);%convert into column vector
Or_c=reshape(Or,[oh*ow,3]);
[ww,hh]=meshgrid(1:ow,1:oh);
P_c=reshape(cat(3,hh,ww),[oh*ow,2]);

for i=1:1:labelnumber%average in superpixel
    index=find(segments==i);
    seg_mean(i,:)=sum(Orlab_c(index,:),1)/length(index);
    dis_mean(i,:)=sum(Or_c(index,:),1)/length(index);
    seg_location_mean(i,:)=sum(P_c(index,:),1)/length(index);
end

% seg_mean=normalization(seg_mean);
% dis_mean=normalization(dis_mean);
%%
segments_prop.num=labelnumber;
segments_prop.seg_mean=seg_mean;
segments_prop.dis_mean=dis_mean;
segments_prop.seg_location_mean=seg_location_mean;
