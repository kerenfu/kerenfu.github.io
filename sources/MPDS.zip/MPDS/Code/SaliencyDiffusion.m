function [stage1,stage1_hull,stage2,bin,map1,map2,map3,map4]=SaliencyDiffusion(A,boundary_label,hull_lable)

%% stage1
map1=1-normalization(A*boundary_label(:,1));

map2=1-normalization(A*boundary_label(:,2));

map3=1-normalization(A*boundary_label(:,3));

map4=1-normalization(A*boundary_label(:,4));

ratio=0.1;

map1=Maptune(map1,ratio);

map2=Maptune(map2,ratio);

map3=Maptune(map3,ratio);

map4=Maptune(map4,ratio);

OutPut=map1+map2+map3+map4; 
    
OutPut=Maptune(OutPut,ratio);

stage1=OutPut;
stage1_hull=OutPut.*hull_lable;
%% stage2
% thre=min(1*mean(stage1(logical(hull_lable))),0.95);%adaptive thresholding
thre=graythresh(stage1(logical(hull_lable)));%Otsu

OutPut((OutPut.*hull_lable)>=thre)=1;
OutPut((OutPut.*hull_lable)<thre)=0;

bin=OutPut;

OutPut=A*OutPut;

stage2=Maptune(OutPut,ratio);



