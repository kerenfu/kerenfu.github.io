function B=set_zeros_diag(A)

labelnumber=size(A,1);

mz=diag(ones(labelnumber,1));%set diagnol to 0

mz=~mz;

B=A.*mz;