function [final_affinity,initial_affinity,error_curve,L]=AffinityOptimization(seg_adjacent_matrix,features,sigma)
%seg_adjacent_matrix: input adjacent matrix; 1 for adjacency and otherwise Inf 
%features: N*d feature vector matrix
%segma: Guaussian variance

if length(sigma)~=size(features,2)
    sigma=repmat(sigma,[1,size(features,2)]);
end

%%%dimension vary different speed
[final_affinity,initial_affinity,error_curve, L]=AEW(features', sigma, seg_adjacent_matrix, 500);

%%%dimension vary the same speed
% [final_affinity,initial_affinity,error_curve,L]=AEW1(features', sigma, seg_adjacent_matrix, 500);

L=L\(diag(sigma));% learning affinity

   