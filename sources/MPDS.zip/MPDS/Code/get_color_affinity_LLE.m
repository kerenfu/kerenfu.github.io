function [final_weight]=get_color_affinity_LLE(segments,seg_adjacent_matrix,color_mean,lamda)

[h,w]=size(segments);

labelnumber=length(color_mean(:,1));

final_weight=zeros(labelnumber);

for i=1:1:labelnumber
    index=find(seg_adjacent_matrix(i,:)==1);
    neighbor=color_mean(index,:);
    neighbor=neighbor';
    curr_vector=color_mean(i,:);
    curr_vector=curr_vector';
    CV=repmat(curr_vector,[1,length(index)]);
    Gram=(CV-neighbor)'*(CV-neighbor);%Gram matrix
    I=eye(length(index));
    coe=(Gram+lamda*I)\ones(length(index),1);
    coe=coe/sum(coe);
    final_weight(i,index)=coe;
end


