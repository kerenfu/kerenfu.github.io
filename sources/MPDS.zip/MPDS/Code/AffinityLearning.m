function final_affinity=AffinityLearning(A)

labelnumber=size(A,1);

if sum(sum(abs(A-A')))>0.01%make A symetric
    A=(A+A')/2;
end

mz=diag(ones(labelnumber,1));%set diagnol to 0

mz=~mz;

final_affinity=A.*mz;

final_affinity=diag(sum(final_affinity,2)+eps)\final_affinity;%self normalization (regard the problem as affinity learning)
