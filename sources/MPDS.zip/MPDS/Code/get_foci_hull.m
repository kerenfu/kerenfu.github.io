function [final_x,final_y]=get_foci_hull(input_img,foveal_number)

[h,w,~]=size(input_img);

if size(input_img,1)<128||size(input_img,2)<128
    input_img=imresize(input_img,[256,256]);
end
out = ittikochmap(input_img);

sal_map=imresize(out.master_map,[h w]);

sal_map=(sal_map-min(sal_map(:)))/(max(sal_map(:))-min(sal_map(:)));

record=[];

radius=round(min([h,w])/6);

foveal=fspecial('disk',radius);

foveal=1-foveal/max(foveal(:));

for i=1:1:foveal_number
    [~,index]=max(sal_map(:));
    x=ceil(index/h);
    y=index-(x-1)*h;
    
    ex1=max(x-radius,1);
    ex2=min(x+radius,w);
    ey1=max(y-radius,1);
    ey2=min(y+radius,h);
    
    efx1=max([2+radius-x,1]);
    efy1=max([2+radius-y,1]);
    efx2=2*radius+1-max([radius+x-w,0]);
    efy2=2*radius+1-max([radius+y-h,0]);
    sal_map(ey1:ey2,ex1:ex2)=sal_map(ey1:ey2,ex1:ex2).*foveal(efy1:efy2,efx1:efx2);
    record=[record;y,x];
end

x=record(:,2); 
y=record(:,1);

dt = DelaunayTri(x,y);
k = convexHull(dt);
final_x=x(k);final_y=y(k); %x,y only contains the boundary corner points of the convex hull


end