function [B]=Maptune(A,ratio)

Total_Num=length(A(:));

temp=sort(A(:),'ascend');

thre=temp(round(Total_Num*ratio));%lower

A(A<=thre)=thre;

thre=temp(Total_Num-1);%upper

A(A>=thre)=thre;

B=normalization(A);
