function [final_affinity,segma]=get_color_affinity(segments,seg_adjacent_matrix,color_mean,var_color)

[h,w]=size(segments);

labelnumber=length(color_mean(:,1));

[seg_edge_matrix,max_diff]=get_edge_matrix(seg_adjacent_matrix,color_mean,labelnumber,'difference');

%%%%%%%%%%%%%%%%%
% final_affinity=exp(-seg_edge_matrix.^2/(2*var_color^2));
%%%%%%%%%%%%%%%%%
final_affinity=exp(-10*seg_edge_matrix/max_diff);
%%%%%%%%%%%%%%%%%
segma=var_color;


