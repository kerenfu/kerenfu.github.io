function show_imgnmap( img , out )
imshow(heatmap_overlay( img , out.master_map_resized ));