Demo for paper:

Keren Fu, Irene Y.H. Gu, Chen Gong, Jie Yang, ��Manifold�\Preserving Robust Saliency
Diffusion by Adaptive Weight Construction,�� Neurocomputing, 175: 336�\347, 2016.

Please cite the paper if you find the code useful.

How to start:

1) Run the "gbvs_install.m" in the "gbvs" folder.  

2) Run "MPDS_Demo.m" to show the demo. The outcomes will be put into the folder "SaliencyMap".

