%
% Adaptive Edge Weighting for Label Propagation
% 
% INPUT
%  X: d (features) times n (instances) input data matrix
%  sigma0: initial sigma, can be scaler or d length 
%  A: adjacent matrix
%  max_iter: maixmum iteration of Gradient Descent
% OUTPUT
%  W: The optimized weighted adjacency matrix
%  W0: The initial adjacency matrix
% REFERENCE
%  M. Karasuyama and H. Mamitsuka, "Manifold-based similarity 
%  adaptation for label propagation", NIPS 2013.
%
function [W W0 error_curve L] = AEW1(X, sigma0, A, max_iter)

  [d n] = size(X);

  ex = 0;
  tol = 1e-4;

  
  L = eye(d);

  Xori = X;
  if length(sigma0) > 1
    sigma0 = reshape(sigma0,d,1);
    X=(sqrt(2)*diag(sigma0))\X;
    dist = squareform(pdist(X').^2);
  else
    X = X ./ (sqrt(2)*sigma0);
    dist = squareform(pdist(X').^2);
  end

  edge_idx = find(A==1);
  W = zeros(n);
  W(edge_idx) = exp(-dist(edge_idx));  
  
  W0=W;
  
  Gd = zeros(n,n,d);
  for i = 1:n
    W_idx{i} = find(W(i,:));
    for j = W_idx{i};
      if W(i,j)
        Gd(i,j,:) = -(X(:,i) - X(:,j)).*(X(:,i) - X(:,j));
%         if length(sigma0) > 1
%           Gd(i,j,:) = Gd(i,j,:) ./ (sigma0(i)*sigma0(j));
%         end
      end
    end
  end

  % --------------------------------------------------
  % Gradient Descent
  % --------------------------------------------------
  error_curve=[];
  
  grad = -ones(d,1)';
  grad = grad ./ norm(grad); % Normalize
  step = 0.05;
  
  for iter = 1:max_iter

      dist = squareform(pdist((L*X)').^2);
       W(edge_idx) = exp(-dist(edge_idx));
       D = sum(W);
      Xest = (diag(1./D)*W*Xori')';
      err = (Xori - Xest);
      sqerr = sum(sum(err.^2));
      
    error_curve=[error_curve;sqerr/(d*n)];
    fprintf('Iter = %d, MSE = %e\n', ...
            iter, sqerr/(d*n));


     L = L - step*diag(grad);

       Lap=diag(D)-W;%���ͼ����Ϊ��ͨͼ
       evalues=eig(Lap);
       
       if length(find(evalues<0.001))>=2
           disp('early stopping!');
           break;
       end
       
       if iter>1&&((sqerr_prev - sqerr) / sqerr_prev) < tol
           disp('iteration converges!');
           break;
       end
       sqerr_prev = sqerr;
  end