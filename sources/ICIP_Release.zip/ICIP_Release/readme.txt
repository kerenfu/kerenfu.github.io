Demo for paper "GEODESIC SALIENCY PROPAGATION FOR IMAGE SALIENT REGION DETECTION" 
by Keren Fu, Chen Gong, Irene Yu-Hua Gu, Jie Yang
in IEEE Int'l Conference on Image Processing (ICIP), 2013.

Our code needs Matlab toolbox "Vlfeat" to be installed, you can down it from: http://www.vlfeat.org/ 