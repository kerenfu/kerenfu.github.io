function top = get_bounding_box(Saliency_Map)
[h,w,s]=size(Saliency_Map);
record_box=[];
scan_step=round(min([w,h])/20);%pixel
for aspect_ratio=0.5:0.25:2   %7 circile
    for window_w=0.1*w:0.1*w:0.8*w %8circle,resulting in 56 window size
        window_h=window_w*aspect_ratio;
        for window_y=1:scan_step:h-window_h%150circle
            for window_x=1:scan_step:w-window_w%150circle
                local_region=Saliency_Map(window_y:window_y+floor(window_h),window_x:window_x+floor(window_w));
                score=(sum(local_region(:))^2)/(window_h*window_w);
                record_box=[record_box;window_x,window_y,window_x+floor(window_w),window_y+floor(window_h),score];
            end
        end
    end
end

top = nms(record_box, 0.5);









end