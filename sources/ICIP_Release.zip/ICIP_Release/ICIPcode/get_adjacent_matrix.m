function seg_adjacent_matrix=get_adjacent_matrix(segments,labelnumber)

seg_adjacent_matrix=ones(labelnumber)*Inf;
[h,w,~]=size(segments);
%%compute adjacent matrix at 8 neighbourhood
for i=1:1:h-1
    for j=1:1:w-1
          if segments(i,j)~=segments(i+1,j)
              seg_adjacent_matrix(segments(i,j),segments(i+1,j))=1;
              seg_adjacent_matrix(segments(i+1,j),segments(i,j))=1;
          end
        
          if segments(i,j)~=segments(i,j+1)
              seg_adjacent_matrix(segments(i,j),segments(i,j+1))=1;
              seg_adjacent_matrix(segments(i,j+1),segments(i,j))=1;
          end
        
          if segments(i,j)~=segments(i+1,j+1)%required if 8 neighbourhood
              seg_adjacent_matrix(segments(i,j),segments(i+1,j+1))=1;
              seg_adjacent_matrix(segments(i+1,j+1),segments(i,j))=1;
          end
          
    end
end

end