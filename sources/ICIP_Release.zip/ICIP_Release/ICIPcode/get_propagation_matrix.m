function seg_propagation_matrix=get_propagation_matrix(seg_edge_matrix,labelnumber)

gamma=0.05;%control intensity
%%%%%%%%%using dijkstra of mex code needs the following code%%%%%%%%%%%%%%%
seg_edge_matrix=seg_edge_matrix+0.00001;%use small number to represent 0
seg_edge_matrix(find(seg_edge_matrix==Inf))=100000;%use large number to represent Inf
seg_edge_matrix=sparse(seg_edge_matrix);

D=dijkstra(seg_edge_matrix,double(1:labelnumber));
temp_weight=exp(-gamma*D);
seg_propagation_matrix=temp_weight./repmat(sum(temp_weight,2),[1 labelnumber]);

end