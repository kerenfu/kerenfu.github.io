function seg_contrast_saliency=get_contrast_saliency(color_mean,labelnumber,up_thre)

seg_contrast_saliency=zeros(labelnumber,1);
for i=1:1:labelnumber
    for j=1:1:labelnumber
            seg_contrast_saliency(i)=seg_contrast_saliency(i)+(min([norm(color_mean(i,:)-color_mean(j,:)),up_thre]))^2;
    end
end


seg_contrast_saliency=(seg_contrast_saliency-min(seg_contrast_saliency(:)))/(max(seg_contrast_saliency(:))-min(seg_contrast_saliency(:)));


end