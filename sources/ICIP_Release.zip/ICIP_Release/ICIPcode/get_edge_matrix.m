function seg_edge_matrix=get_edge_matrix(seg_adjacent_matrix,seg_color,labelnumber)

seg_edge_matrix=ones(labelnumber)*Inf;
d0=5;%5 for default
for i=1:1:labelnumber
    index=find(seg_adjacent_matrix(i,:)==1);%find adjacency for ith superpixel
    diff=sqrt(sum((repmat(seg_color(i,:),[length(index),1])-seg_color(index,:)).^2,2));%calculate color difference
    seg_edge_matrix(i,index)=diff';
end
    
%small weight clip
Min_Row=min(seg_edge_matrix,[],2);
d_threshold=mean(Min_Row);
for i=1:1:labelnumber
    for j=1:1:labelnumber
        if seg_edge_matrix(i,j)<=max([d_threshold,d0])
            seg_edge_matrix(i,j)=0;
        end
    end
end
