% Demo for paper "GEODESIC SALIENCY PROPAGATION FOR IMAGE SALIENT REGION DETECTION" 
% by Keren Fu, Chen Gong, Irene Yu-Hua Gu, Jie Yang
% To appear in ICIP 2013.
% Files are coded by Keren Fu {fkrsuper@sjtu.edu.cn}

clc;
close all;
clear all;
addpath('./HarrisCorner/');
addpath('./ICIPcode/');

abc_path =  './Test_Img/';%input dir     
output_path = './SaliencyMap/';%output dir
superpixel_path = './Superpixels/';%temp dir for superpixel

abc_filelist = dir([abc_path '/*.jpg']);            
len = length(abc_filelist);

for Pix=1:len 
Pix
string_file=abc_filelist(Pix).name
Or= double(imread([abc_path string_file]))/255;
[h,w,s]=size(Or);
ratio=400/max([h,w]);
Or=imresize(Or,ratio,'nearest');%resize to max(w,h)=400
[h,w,s]=size(Or);
Orlab = vl_xyz2lab(vl_rgb2xyz(Or)) ;
Im=im2single(Orlab);
Saliency_Map=zeros(h,w);

t1=clock;
%%
%%--------------------VLfeat SLIC superpixels----------------------------%%
K=250;

% regularizer = 100;
% 
% segments=slic_segmentation(Im,K,regularizer);

%%-----------------Faster SLIC superpixels using EXE---------------------%%
imwrite(Or,[superpixel_path,string_file(1:end-4) '.bmp']);
imname=[string_file(1:end-4) '.bmp'];% the slic software support only the '.bmp' image
comm=['SLICSuperpixelSegmentation' ' ' [superpixel_path imname] ' ' int2str(20) ' ' int2str(K) ' ' superpixel_path];
system(comm);     
spname=[superpixel_path string_file(1:end-4) '.dat'];
segments=ReadDAT([h,w],spname); % superpixel label matrix

delete([superpixel_path string_file(1:end-4) '.bmp']);
delete([superpixel_path string_file(1:end-4) '_SLIC' '.bmp']);
delete([superpixel_path string_file(1:end-4) '.dat']);

labelnumber=max(segments(:))

seg_mean=zeros(labelnumber,3);%mean color in LAB
dis_mean=zeros(labelnumber,3);%mean color in RGB
seg_location_mean=zeros(labelnumber,2);%mean position

Orlab_c=reshape(Orlab,[h*w,3]);%convert into column vector
Or_c=reshape(Or,[h*w,3]);
[ww,hh]=meshgrid(1:w,1:h);
P_c=reshape(cat(3,hh,ww),[h*w,2]);

for i=1:1:labelnumber
    index=find(segments==i);
    seg_mean(i,:)=sum(Orlab_c(index,:),1)/length(index);
    dis_mean(i,:)=sum(Or_c(index,:),1)/length(index);
    seg_location_mean(i,:)=sum(P_c(index,:),1)/length(index);
end

%%
%%----------------------get adjacent and edge matrix---------------------%%
seg_adjacent_matrix=get_adjacent_matrix(segments,labelnumber);%adjacent matrix

seg_edge_matrix=get_edge_matrix(seg_adjacent_matrix,seg_mean,labelnumber);
%%
%%--------------------get geodesic propagation matrix-------------------%%
seg_propagation_matrix=get_propagation_matrix(seg_edge_matrix,labelnumber);

%%
%%----------------------get global contrast saliency---------------------%%   
Saliency=get_contrast_saliency(seg_mean,labelnumber,100);
%%
%%---------------------find convex hull for boosted corners--------------%%
[x,y]=get_convex_hull(Or);
%%
%%--------------------clip saliency values outside the hull--------------%%
index=inpolygon(round(seg_location_mean(:,2)),round(seg_location_mean(:,1)),x,y);%1 for inside and 0 for outside
Saliency=Saliency.*index; 
%%
%%--------------------------saliency propagation-------------------------%%
Saliency=seg_propagation_matrix*Saliency;
Saliency=(Saliency-min(Saliency(:)))/(max(Saliency(:))-min(Saliency(:)));
%%
%%--------------------------saliency assignment--------------------------%%
for i=1:1:labelnumber
    Saliency_Map(segments==i)=Saliency(i);
end

t2=clock; 
pre_time=etime(t2,t1);
disp(num2str(pre_time)); 

%%
%%--------------------Window Sampling using NMS--------------------------%%

Binary_Map=im2bw(Saliency_Map,min([2*mean(Saliency_Map(:)),0.999999]));%binary the map using adaptive threshold

top_rectangle = get_bounding_box(Binary_Map);%sliding window with NMS (Non-Maximum-Suppresion)

rx1=top_rectangle(1,1);%choose the top best rectangle as object
ry1=top_rectangle(1,2);
rx2=top_rectangle(1,3);
ry2=top_rectangle(1,4);

expand_ratio=1.2;%expand the rectangle to be more visually satisfactory
final_rx1=max([(rx1+rx2)/2-expand_ratio*(rx2-rx1)/2,1]);
final_rx2=min([(rx1+rx2)/2+expand_ratio*(rx2-rx1)/2,w]);

final_ry1=max([(ry1+ry2)/2-expand_ratio*(ry2-ry1)/2,1]);
final_ry2=min([(ry1+ry2)/2+expand_ratio*(ry2-ry1)/2,h]);

%%----------------------------output-------------------------------------%%
figure(1);
imshow(Or,[0 1]);
rectangle('Position', [final_rx1 final_ry1 final_rx2-final_rx1+1 final_ry2-final_ry1+1],'LineWidth',5,'EdgeColor','r');
saveas(gcf,strcat(output_path,string_file,'_BOX.png'))%rectangle result
imwrite(Saliency_Map,strcat(output_path,string_file,'_SP.png'));%saliency map 
imwrite(Binary_Map,strcat(output_path,string_file,'_BM.png'));%binary map

end


