The code (V2) is for: 
===========================================================================
K. Fu, I. Gu, J. Yang  
Spectral Salient Object Detection 
Neurocomputing 2017       
===========================================================================
The code has been tested on Window with 32bit/62bit matlab.
===========================================================================
How to run a simple demo:
===========================================================================
0a. put test images (*.jpg format) into 'Test_Img' folder; 
1a. run 'Demo.m' to see the results; 
