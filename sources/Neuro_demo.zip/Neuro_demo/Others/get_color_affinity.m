function final_affinity=get_color_affinity(segments,color_mean,var_color,num_ring)

[h,w]=size(segments);

labelnumber=length(color_mean(:,1));


seg_adjacent_matrix=get_adjacent_matrix(segments,num_ring);%superpixel adjacency

[seg_edge_matrix,max_diff]=get_edge_matrix(seg_adjacent_matrix,color_mean,labelnumber,'difference');

seg_edge_matrix=seg_edge_matrix/max_diff;%normalized color distance

% color_affinity=seg_edge_matrix;
% color_affinity(color_affinity==Inf)=0;

color_affinity=exp(-(seg_edge_matrix*var_color).^1);

% alpha=0.4;
% color_affinity=1./(1+exp(12/alpha*(seg_edge_matrix-alpha/2)));

% alpha=0.4;
% color_affinity=max(-(1/alpha)*seg_edge_matrix+1,eps);

mz=diag(ones(labelnumber,1));
mz=~mz;
final_affinity=color_affinity.*mz;


