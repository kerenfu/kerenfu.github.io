function segments_prop=superpixel_prop1(Or,Orlab,Distr,segments)

labelnumber=double(max(segments(:)));%total number

[oh,ow,os]=size(Or);%get new size

seg_mean=zeros(labelnumber,os);%mean color in LAB
dis_mean=zeros(labelnumber,os);%mean color in RGB
seg_location_mean=zeros(labelnumber,2);%mean position
seg_area=zeros(labelnumber,1);%region area
seg_dist=zeros(labelnumber,1);%region distribution 

Orlab_c=reshape(Orlab,[oh*ow,os]);%convert into column vector
Or_c=reshape(Or,[oh*ow,os]);
[ww,hh]=meshgrid(1:ow,1:oh);
P_c=reshape(cat(3,hh,ww),[oh*ow,2]);

for i=1:1:labelnumber
    index=find(segments==i);
    seg_mean(i,:)=sum(Orlab_c(index,:),1)/length(index);
    dis_mean(i,:)=sum(Or_c(index,:),1)/length(index);
    seg_location_mean(i,:)=sum(P_c(index,:),1)/length(index);
    seg_area(i)=length(index);
    seg_dist(i)=sum(Distr(index))^1/length(index);
end


%%%%%%%%%%%%%%%property%%%%%%%%%%%%%%%%%
segments_prop.num=labelnumber;
segments_prop.seg_mean=seg_mean;
segments_prop.dis_mean=dis_mean;
segments_prop.seg_location_mean=seg_location_mean;
segments_prop.seg_area=seg_area;
segments_prop.seg_dist=seg_dist;
end