clc;
close all;
clear all;

addpath('./ICMEcode/');%ICME code
addpath('./Others/');%other support
addpath(genpath('./FKR_toolbox/'));%unified code
addpath(genpath('./piotr_toolbox/'));%piotr toolbox
addpath(genpath('./RF_edge_toolbox'));%edge detection toolbox

input_path = [ 'Test_Img\'];%input image path    
superpixel_path = './Superpixels/';

input_filelist = dir([input_path '/*.jpg']); %get input image list, define YOUR FORMAT HERE
output_path= ['SaliencyMap\'];%output image path
% delete([output_path,'*.png']);
Distr_O=double(imread('CenterBias\prior.png'))/255;%distribution prior

len = length(input_filelist);

model=load('./RF_edge_toolbox/models/forest/modelBsds'); model=model.model; %edge detection para.
model.opts.nms=-1; model.opts.nThreads=4;
model.opts.multiscale=1; model.opts.sharpen=2;

Enable_EdgeDetect=1;%------------------default 1-------------------------%
Enable_Smoothing=1;%------------------default 1-------------------------%
Enable_Hierarchy=1;%------------------default 1-------------------------%
Enable_Multiscale=0;%------------------default 0-------------------------%

%------------------Parameters-------------------------%
cncut_lamda=100;%0 or 100
lamda_c=10;
lamda_e=10;
Num_ring=1;
LEVEL=10;%number of region:2 4 7 10 20

%------------------start processing-------------------------%
for Pix=1:len 
Pix
t1=clock; 
string_file=input_filelist(Pix).name
Or=imread([input_path string_file]);

if size(Or,3)==1%if gray image, convert it to 3 channels
    Or=repmat(Or,[1,1,3]);
end

[Or,w]=removeframe(Or);%remove image frame

[oh,ow,os]=size(Or);%get new size

Or= double((Or))/255;

Orlab = vl_xyz2lab(vl_rgb2xyz(Or)) ;%rgb to xyz to lab

Distr=imresize(Distr_O,[oh,ow]);%resize distribution prior

%% 
%%load pre-trained edge detection model and set opts (see edgesDemo.m)%%
if exist([input_path string_file(1:end-4) '_EdgeMap.png'],'file')
    disp('Skipping edge detection...'); 
    edge_map=double(imread([input_path string_file(1:end-4) '_EdgeMap.png']));
else
    disp('Performing edge detection...'); 
    [edge_map,~,~,~]=edgesDetect(Or,model);
    imwrite(edge_map,[input_path string_file(1:end-4) '_EdgeMap.png']);
end
edge_map=edge_map/max(edge_map(:));    

% imwrite(edge_map,strcat(string_file(1:end-4),'_edge.png'));

if Enable_Multiscale==1
    lower_bound=1;upper_bound=3;
else
    lower_bound=2;upper_bound=2;%1 2 3
end

for sup_number=lower_bound:1:upper_bound
%%-------------------------SLIC superpixels------------------------------%%
segments=get_superpixel(Or,100*2^(sup_number-1),superpixel_path,string_file);
labelnumber=max(segments(:));
segments_prop=superpixel_prop(Or,Orlab,Distr,segments);%get superpixel property

%%-------------------------boundary superpixels--------------------------%%
boundary_label=get_boundary_label(segments,labelnumber);
boundary_all=boundary_label(:,1)|boundary_label(:,2)|boundary_label(:,3)|boundary_label(:,4);
boundary_color=segments_prop.seg_mean(boundary_all,:);%color vector of boundary superpixel (boundary_pixel_length*3 matrix)
boundary_pixel_length=length(boundary_color(:,1));%number of boundary superpixel

%%---------------------------graph affinity----------------------------%%
Lab_affinity=get_color_affinity(segments,segments_prop.seg_mean,lamda_c,Num_ring);
W=Lab_affinity; %color affinity only
%%%%%%%%%%%%%   %combine edge affinity
if Enable_EdgeDetect==1
    Edge_affinity=get_edge_matrix_from_edge(segments,segments_prop.seg_location_mean,edge_map,Lab_affinity,lamda_e,Num_ring);
    W=sqrt(Lab_affinity.*Edge_affinity);
end
%%-----------------------hierarchical 2-way Ncut-----------------------%%
cluster_index=spectral_segmentation(W,LEVEL-1,boundary_all,cncut_lamda);  
%%
if Enable_Hierarchy==0
    cluster_index=[1:labelnumber]';
end
%%
sum_backgroundness=zeros(oh,ow);
for itr_clu=1:1:size(cluster_index,2)
    %     itr_clu
    cluster_index_curr=cluster_index(:,itr_clu);
    current_segments=segments;
    for i=1:1:segments_prop.num
        current_segments(segments==i)=cluster_index_curr(i);%superpixel index for current hierachy
    end
    current_segments_prop=superpixel_prop(Or,Orlab,Distr,current_segments);%get region property
    current_segments_prop.area=zeros(max(current_segments(:)),1);
    for temp_itr=1:1:max(current_segments(:))
        current_segments_prop.area(temp_itr)=length(find(cluster_index_curr==temp_itr));
    end
    boundary_label=im2bw(get_boundary_label(current_segments,max(current_segments(:))));%get boundary label
    %measure No.1 (surroundness) in the paper
    S3=sum([boundary_label(:,1),boundary_label(:,2),boundary_label(:,3),boundary_label(:,4)],2);
    S3=double((S3<=1));
    %measure No.2 (figure-ground contrast) in the paper
    S1=zeros((max(current_segments(:))),1);
    for temp_itr=1:1:max(current_segments(:))
        dis_list=sqrt(sum((repmat(current_segments_prop.seg_mean(temp_itr,:),[boundary_pixel_length,1])-boundary_color).^2,2));
        dis_list=sort(dis_list,1,'ascend');
        S1(temp_itr)=sum(dis_list(1:round(boundary_pixel_length/4)))/round(boundary_pixel_length/4);
    end
    S1=normalization2(S1);%normalization
    %measure No.3 (center bias) in the paper
    S2=current_segments_prop.seg_dist;
    %measure No.4 center-surround measure in the paper
    %     local_adjacent_matrix=get_adjacent_matrix_onering(current_segments);
    %     S4=zeros((max(current_segments(:))),1);
    %     for i=1:1:max(current_segments(:))
    %         cs_label=(local_adjacent_matrix(i,:)==1);
    %         cs_color=current_segments_prop.seg_mean(cs_label,:);
    %         cs_area=current_segments_prop.area(cs_label,:);
    %         cs_length=length(cs_color(:,1));%number of surrounding region
    %         S4(i)=sum(sqrt(sum((repmat(current_segments_prop.seg_mean(i,:),[cs_length,1])-cs_color).^2,2)).*cs_area);
    %         S4(i)=S4(i)/sum(cs_area);
    %     end
    %     S4=normalization2(S4);%normalization
    
    %Joint combination of S1,S2,S3 (equ.4 in the paper) and S4
    S=normalization(S2.*S3.*S1);
    %     S=normalization(S2.*S3.*S1.*S4);
    tsaliency_map=zeros(oh,ow);
    for i=1:1:max(current_segments(:))
        tsaliency_map(current_segments==i)=S(i);
    end
    
    %Cross-level accumulation
    if itr_clu==1&&sup_number==lower_bound
        final_saliency_map= tsaliency_map;
    else
        final_saliency_map=final_saliency_map + tsaliency_map;
    end
end

end
final_saliency_map=normalization(final_saliency_map);
%%-----------------------optional smoothing-----------------------%%
%%%using fine level superpixel to refine
if Enable_Smoothing==1
    current_segments_prop=superpixel_prop1(final_saliency_map,final_saliency_map,Distr,segments);%get superpixel property
        alpha=0.99;
        D  = diag(sum(W));
        optAff =(eye(labelnumber)-alpha*(D\W))\eye(labelnumber);

        final_filtered=normalization(optAff*current_segments_prop.seg_mean);

        final_saliency_map=zeros(oh,ow);
        for i=1:1:max(segments(:))
                  final_saliency_map(segments==i)=final_filtered(i);
        end  
end
%%----------------------------------------------------------------%%

saliency_map=zeros(w(1),w(2));

saliency_map(w(3):w(4),w(5):w(6))=final_saliency_map;

imwrite(saliency_map,[output_path,string_file(1:end-4),'_SS+.png']);
end
   
