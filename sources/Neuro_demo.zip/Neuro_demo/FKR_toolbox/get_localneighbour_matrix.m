function seg_localneighbour_matrix=get_localneighbour_matrix(seg_adjacent_matrix,labelnumber,hop_num)
seg_localneighbour_matrix=seg_adjacent_matrix;
if hop_num>1
    for itr=1:1:hop_num-1%repeatly expand the neighbour 'hop_num' times
        seg_adjacent_matrix=seg_localneighbour_matrix;
        % % %expand the neighbour of i
            for i=1:1:labelnumber
                index=find(seg_adjacent_matrix(i,:)==1);
                for j=1:1:length(index)
                    indext=find(seg_adjacent_matrix(index(j),:)==1);
                    index=[index,indext];
                end 
                index=unique(index);
                seg_localneighbour_matrix(i,index)=1;
                seg_localneighbour_matrix(index,i)=1;
            end
    end
end
seg_localneighbour_matrix(find(seg_localneighbour_matrix==0))=Inf;%set the unconnected to Inf