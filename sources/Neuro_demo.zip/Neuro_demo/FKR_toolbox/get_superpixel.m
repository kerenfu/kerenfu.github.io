function segments=get_superpixel(Or,K,superpixel_path,string_file)

[oh,ow,~]=size(Or);

%%slic superpixel-exe
imwrite(Or,[superpixel_path,string_file(1:end-4) '.bmp']);
imname=[string_file(1:end-4) '.bmp'];% the slic software support only the '.bmp' image
comm=['SLICSuperpixelSegmentation' ' ' [superpixel_path imname] ' ' int2str(20) ' ' int2str(K) ' ' superpixel_path];
system(comm);
spname=[superpixel_path string_file(1:end-4) '.dat'];
segments=ReadDAT([oh,ow],spname); % superpixel label matrix

delete([superpixel_path string_file(1:end-4) '.bmp']);
delete([superpixel_path string_file(1:end-4) '_SLIC' '.bmp']);
delete([superpixel_path string_file(1:end-4) '.dat']);

end