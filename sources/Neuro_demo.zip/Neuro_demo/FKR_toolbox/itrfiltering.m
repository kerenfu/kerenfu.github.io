 function output_vector=itrfiltering(propagation_matrix,input_vector,itr_number)
 
 fil_vector=input_vector;
 
 for i=1:1:itr_number
     fil_vector=propagation_matrix*fil_vector;
     
     fil_vector=(fil_vector-min(fil_vector))/(max(fil_vector)-min(fil_vector));
     
%      if isempty(find(fil_vector==0))==1
%          break;
%      end
 end
 
 output_vector=fil_vector;
 
 end