function Corner_list = Color_Boosted_Harris_Detector(Img)
sigma_g=1.5;
sigma_a=5;
nPoints=30;

Mboost = BoostMatrix(Img);

if max(max(abs(Img(:,:,1)-Img(:,:,2))))==0;
    Mboost=eye(3);
end

% apply matrix to image
boost_im= BoostImage(Img,Mboost);

% Optional check if boosting matrix is identity matrix after color boosting
% Mboost2 = BoostMatrix(boost_im)

% compute Harris Energy
[EnIm]= ColorHarris(boost_im,sigma_g,sigma_a,0.04,1);

% extract corners in total nPoints
[x_max,y_max,corner_im2,num_max]=getmaxpoints(EnIm,nPoints);

% visualize corners 
% output_im2=visualize_corners(input_im,corner_im2);

Corner_list=[x_max,y_max];

end