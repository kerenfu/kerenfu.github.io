function seg_differential_matrix=get_differential_matrix(seg_color,labelnumber)
tmp1=repmat(permute(seg_color,[1 3 2]),[1 labelnumber 1]);
tmp2=repmat(permute(seg_color',[3 2 1]),[labelnumber 1 1]);
seg_differential_matrix=sum((tmp1-tmp2).^2,3).^0.5;%unormalized LAB distance
% seg_differential_matrix=seg_differential_matrix/max(seg_differential_matrix(:));%normalize
% max(seg_differential_matrix(:))
    %small weight clip
    Min_Row=min(seg_differential_matrix,[],2);
    d_threshold=mean(Min_Row);
    for i=1:1:labelnumber
        for j=1:1:labelnumber
            if seg_differential_matrix(i,j)<=d_threshold
                seg_differential_matrix(i,j)=0;
            end
        end
    end