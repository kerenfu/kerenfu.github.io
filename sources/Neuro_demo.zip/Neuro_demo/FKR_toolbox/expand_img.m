function [Img_Ex,ye,xe]=expand_img(Img,Extend_Ratio,Model)
%%%%%%%%%%%%%%%%
%expand the image using boundary part
%input: Img
%%%%%%%%%%%%%%%%
[oh,ow,os]=size(Img);

ye=round(Extend_Ratio*oh);
xe=round(Extend_Ratio*ow);
Img_Ex=zeros(oh+2*ye,ow+2*xe,os);
Img_Ex(ye+1:oh+ye,xe+1:ow+xe,:)=Img;%center
if strcmp(Model,'boundary')==1
    Img_Ex(1:ye,xe+1:ow+xe,:)=repmat(Img(1,:,:),[ye,1,1]);%up
    Img_Ex(oh+ye+1:oh+2*ye,xe+1:ow+xe,:)=repmat(Img(oh,:,:),[ye,1,1]);%down

    Img_Ex(ye+1:oh+ye,1:xe,:)=repmat(Img(:,1,:),[1,xe,1]);%left
    Img_Ex(ye+1:oh+ye,ow+xe+1:ow+2*xe,:)=repmat(Img(:,ow,:),[1,xe,1]);%right

    Img_Ex(1:ye,1:xe,:)=repmat(Img(1,1,:),[ye,xe,1]);%upleft
    Img_Ex(oh+ye+1:oh+2*ye,1:xe,:)=repmat(Img(oh,1,:),[ye,xe,1]);%downleft
    Img_Ex(1:ye,ow+xe+1:ow+2*xe,:)=repmat(Img(1,ow,:),[ye,xe,1]);%upright
    Img_Ex(oh+ye+1:oh+2*ye,ow+xe+1:ow+2*xe,:)=repmat(Img(oh,ow,:),[ye,xe,1]);%downright
elseif strcmp(Model,'partial')==1
    Img_Ex(1:ye,xe+1:ow+xe,:)=Img(1:ye,:,:);%up
    Img_Ex(oh+ye+1:oh+2*ye,xe+1:ow+xe,:)=Img(oh-ye+1:oh,:,:);%down

    Img_Ex(ye+1:oh+ye,1:xe,:)=Img(:,1:xe,:);%left
    Img_Ex(ye+1:oh+ye,ow+xe+1:ow+2*xe,:)=Img(:,ow-xe+1:ow,:);%right

    Img_Ex(1:ye,1:xe,:)=Img(1:ye,1:xe,:);%upleft
    Img_Ex(oh+ye+1:oh+2*ye,1:xe,:)=Img(oh-ye+1:oh,1:xe,:);%downleft
    Img_Ex(1:ye,ow+xe+1:ow+2*xe,:)=Img(1:ye,ow-xe+1:ow,:);%upright
    Img_Ex(oh+ye+1:oh+2*ye,ow+xe+1:ow+2*xe,:)=Img(oh-ye+1:oh,ow-xe+1:ow,:);%downright
else
    error('Model should be "boundary" or "partial"');
end

end