function final_affinity=get_edge_matrix_from_edge(segments,seg_location,edge_map,color_affinity,var_edge,num_ring)
%get difference from edge detection

seg_adjacent_matrix=get_adjacent_matrix(segments,num_ring);%superpixel adjacency,boundary connected

labelnumber=length(seg_adjacent_matrix(:,1));

%%%%%%%%%%%%%%%%%%%%%%%%%esnure centers are inside%%%%%%%%%%%%%%%%%%%%%%%%%%
% check seg_location segments
% total_num=0;
% for i=1:1:labelnumber 
%     current_locatation=round(seg_location(i,:));
%     [ii,jj]=find(segments==i);  
%     check_list=[ii,jj];    
%     if(isempty(find(sum(abs(repmat(current_locatation,[length(ii),1])-check_list),2)==0))==1)
%         seg_location(i,:)=check_list(randi([1,length(ii)]),:);%%lie out, and change the coordinates randomly
%         total_num=total_num+1;
%     end
% end 
% if total_num>0
%     disp([num2str(total_num),' superpixels are corrected']);
% end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
seg_edge_matrix=ones(labelnumber)*Inf;

boundary_label=get_boundary_label(segments,labelnumber);

boundary_label=boundary_label(:,1)|boundary_label(:,2)|boundary_label(:,3)|boundary_label(:,4);

max_diff=0;
for i=1:1:labelnumber
    for j=i+1:1:labelnumber
        if seg_adjacent_matrix(i,j)==1
            if boundary_label(i)==1&&boundary_label(j)==1%first set affinity to 1
                current_edge=0;
            else
                pts=linepts(seg_location(i,:),seg_location(j,:));
                index=sub2ind(size(edge_map),pts(:,1),pts(:,2));
                current_edge=max(edge_map(index));
            end

            seg_edge_matrix(i,j)=current_edge;
            seg_edge_matrix(j,i)=current_edge;
            if current_edge>max_diff
                max_diff=current_edge;
            end
        end
    end
end
seg_edge_matrix=seg_edge_matrix/max_diff;
final_affinity=exp(-seg_edge_matrix*var_edge);

for i=1:1:labelnumber%revise boundary affinity to color affinity
    for j=i+1:1:labelnumber
            if boundary_label(i)==1&&boundary_label(j)==1
                final_affinity(i,j)=color_affinity(i,j);
                final_affinity(j,i)=color_affinity(j,i);
            end
    end
end

mz=diag(ones(labelnumber,1));
mz=~mz;
final_affinity=final_affinity.*mz;

