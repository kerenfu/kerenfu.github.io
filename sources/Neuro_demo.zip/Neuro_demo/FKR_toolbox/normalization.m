function output = normalization(input)

output=(input-min(input(:)))/(max(input(:))-min(input(:))+0.0000000000001);

end