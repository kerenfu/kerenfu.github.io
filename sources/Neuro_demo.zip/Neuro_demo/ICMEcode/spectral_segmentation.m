function cluster=spectral_segmentation(W,nclust,boundary_label,lamda)

labelnumber=size(W,1);

cluster=zeros(labelnumber,nclust);

D  = diag(sum(W)); 

L=D-W;
%%%generate U according to boundary_label
bd_num=sum(boundary_label);
con_num=bd_num-1;
U=zeros(labelnumber,con_num);
bd_index=find(boundary_label);
for i=1:1:con_num
    U(bd_index(i),i)=0.5;
    U(bd_index(i+1),i)=-0.5;
end

H=L+lamda*(U*U');

% H=L+0.01*diag(boundary_label);

% H=L+1000*eye(length(boundary_label));
[V eig_v] = eig(H, D);%generalized eigen problem

tkmind=v_cut(V(:,2));%2way-cut
cluster(:,1)=tkmind;

new_generated_label=[1,2];%new-generated label 
cut_record=[];
for i=2:1:nclust
    for it=1:2
        find_index=find(cluster(:,i-1)==new_generated_label(it));
        WW=W(find_index,find_index);%sub-affinity matrix
        DD  = diag(sum(WW)); 
        L=DD-WW;
        [V ~] = eig(L, DD);
        if size(V,2)>=2
            minE=((V(:,2)'*L*V(:,2))/(V(:,2)'*DD*V(:,2)));%/length(find_index);%cut energy (further divide region area, see page 3 right column paragraph 2)
            cut_record=[cut_record;{new_generated_label(it),double(minE),double(V(:,2)),find_index}];
        else
            minE=10000;
            cut_record=[cut_record;{new_generated_label(it),double(minE),double(V(:,1)),find_index}];
        end
    end  
    
    [~,temp_index]=min(cell2mat(cut_record(:,2)));
    current_label=cut_record{temp_index,1};
    tkmind=v_cut(cut_record{temp_index,3});
    find_index=cut_record{temp_index,4};
    
    temp_copy=tkmind;
    tkmind(temp_copy==1)=current_label;
    tkmind(temp_copy==2)=i+1;
    cluster(:,i)=cluster(:,i-1);
    cluster(find_index,i)=tkmind;
    new_generated_label=[current_label,i+1];
    
    cut_record(temp_index,:)=[];
    
end








