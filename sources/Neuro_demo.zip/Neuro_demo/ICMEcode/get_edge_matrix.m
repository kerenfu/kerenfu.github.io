function [seg_edge_matrix,max_diff]=get_edge_matrix(seg_adjacent_matrix,seg_color,labelnumber,model)
%model='diff' or 'aff' 
if strcmp(model,'difference')==1
    seg_edge_matrix=ones(labelnumber)*Inf;
    max_diff=0;
    for i=1:1:labelnumber
        index=find(seg_adjacent_matrix(i,:)==1);%find adjacency for ith superpixel
        diff=sqrt(sum((repmat(seg_color(i,:),[length(index),1])-seg_color(index,:)).^2,2));%calculate color difference
        seg_edge_matrix(i,index)=diff';
        max_diff=max([max_diff,max(diff)]);
    end
elseif strcmp(model,'affinity')==1
    seg_edge_matrix=zeros(labelnumber);
    alpha=0.1;%parameter for gaussian
    for i=1:1:labelnumber
        index=find(seg_adjacent_matrix(i,:)==1);%find adjacency for ith superpixel
        diff=sum((repmat(seg_color(i,:),[length(index),1])-seg_color(index,:)).^2,2);%calculate difference
        aff=exp(-alpha*diff);
        seg_edge_matrix(i,index)=aff';
    end
else
    error('model should be "difference" or "affinity" ');
end

end