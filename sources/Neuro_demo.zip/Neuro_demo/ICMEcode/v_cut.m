function [tkmind]=v_cut(V)

%tkmind=(V>=0)+(V<0)*2;
tkmind=(V>=mean(V))+(V<mean(V))*2;
