function output = normalization(input)

output=(input-min(input(:)))/(max(input(:))-min(input(:))+eps);

end