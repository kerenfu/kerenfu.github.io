function output = normalization2(input)

output=(input-min(input(:)))/(max(input(:))-min(input(:))+eps)+0.1;

end